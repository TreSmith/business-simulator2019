﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Simulator
{
    class Stock
    {
        #region Fields

        private const int _defaulcellcost = 100;
        private const int _defaulttvcost = 150;
        private const int _defaultPCcost = 250;

        private const int _defaultphone = 0;
        private const int _defaulttv = 0;
        private const int _defaultPC = 0;

        private const int _defaultmax = 100;
        private const int _phoneStore = 5;
        private const int _tvStore = 15;
        private const int _computerStore = 10;

        public int phonecost;   //Amount Stock Costs
        public int tvcost;
        public int computercost;

        public int phone;   //Amount of stock owned
        public int tv;
        public int computer;

        private int _maxstock;
        public int currentstock = 0;


        #region Getters and Setters

        public int PhoneStore
        {
            get
            {
                return _phoneStore;
            }
        }

        public int TVStore
        {
            get
            {
                return _tvStore;
            }
        }

        public int ComputerStore
        {
            get
            {
                return _computerStore;
            }
        }

        public int DefaultCellCost
        {
            get
            {
                return _defaulcellcost;
            }
        }

        public int DefaultTVCost
        {
            get
            {
                return _defaulttvcost;
            }
        }

        public int DefaultPCCost
        {
            get
            {
                return _defaultPCcost;
            }
        }

        public int DefaultMax
        {
            get
            {
                return _defaultmax;
            }
        }

        public int MaxStock
        {
            get
            {
                return _maxstock;
            }
            set
            {
                _maxstock = value;
            }
        }

        #endregion 

        #endregion

        #region Constructor

        public Stock()     //Constructor
        {
            phonecost       = _defaulcellcost;
            tvcost          = _defaulttvcost;
            computercost    = _defaultPCcost;

            phone = _defaultphone;
            tv = _defaulttv;
            computer = _defaultPC;

            _maxstock = _defaultmax;
        }




        #endregion

        #region Methods

        public int BuyStock(int amount, int type, Player p1)
        {
            int stock=currentstock, x=0;   //X is used to test how many objects were successfully purchased
            for (int i=0; i < amount; i++)
            {
               if(type == 0) //Cell Phone
                {
                    stock = stock + _phoneStore; //Check if storage is full
                    if (stock > _maxstock)
                        amount=0;
                    else
                    {
                        if (p1.Money > 100)
                        {
                            x++;
                            p1.Money -= 100;   //Take money from Player's Balance
                            currentstock = currentstock + 5;
                            phone++;
                        }
                        else
                            amount = 0;
                    }
                }

               if(type==1) //TV
                {
                    stock = stock + _tvStore; //Check if storage is full
                    if (stock > _maxstock)
                        amount = 0;
                    else
                    {
                        if (p1.Money > 150)
                        {
                            x++;
                            p1.Money -= 150;   //Take money from players balance
                            currentstock = currentstock + 15;
                            tv++;
                        }
                        else
                            amount = 0;
                    }
                }
               if(type == 2) //Computer
                {
                    stock = stock + _computerStore;     //Check if storage is full
                    if (stock > _maxstock)
                        amount=0;
                    else
                    {
                        if (p1.Money > 250)
                        {
                            x++;
                            p1.Money -= 250;   //Take money from Player's balance
                            currentstock = currentstock + 10; //If storage is not full then buy stock
                            computer++;
                        }
                        else
                            amount = 0;
                    }
                }
            }
            return x;

        }


        #endregion

    }
}
