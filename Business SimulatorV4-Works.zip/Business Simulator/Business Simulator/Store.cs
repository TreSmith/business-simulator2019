﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Simulator
{
    class Store : Stock
    {

        #region Fields

        public int Sellingmodifier = 0;
        private int _expenses = 200;
        private readonly int _phoneprice = 500;
        private readonly int _tvprice = 750;
        private readonly int _computerprice = 1000;

        #endregion 

        #region Constructor

        public Store()
        {
            phonecost = DefaultCellCost;
            tvcost = DefaultTVCost;
            computercost = DefaultPCCost;

            phone = 0;
            tv = 0;
            computer = 0;

            MaxStock = DefaultMax;
        }

        #endregion

        #region Methods

        public void SmallStoreUpgrade()
        {
            _expenses = _expenses * 3;
            MaxStock = 500;
            Sellingmodifier++;
        }

        public void MediumStoreUpgrade()
        {
            _expenses = _expenses * 3;
            MaxStock = 1000;
            Sellingmodifier+=2;
        }

        public void LargeStoreUpgrade()
        {
            _expenses = _expenses * 3;
            MaxStock = 2000;
            Sellingmodifier+=3;
        }

        public int SellStock(int flag, Player p1)
        {
            int y=0;
            double x=0;
            double percent;
            Random rnd = new Random();
            
            percent = rnd.Next(5) + Sellingmodifier;
            percent = percent / 10;
             
            if(flag == 0)   //Sell Phones
            {
                x = phone * percent;
                y = Convert.ToInt32(x);
                phone -= y;
                currentstock -= y * PhoneStore;

                y = y * _phoneprice;
            }

            if(flag == 1)   //Sell TVs
            {
                x = tv * percent;
                y = Convert.ToInt32(x);
                tv -= y;
                currentstock -= y * TVStore;

                y = y * _tvprice;
            }

            if (flag == 2)  //Sell Computers
            {
                x = computer * percent;
                y = Convert.ToInt32(x);
                computer -= y;
                currentstock -= y * ComputerStore;

                y = y * _computerprice;
            }

            p1.Money = p1.Money + y;  //Add amount of money to players account

            return y;
        }

        public int Expenses(Player p1)
        {
            p1.Money -= _expenses;
            return _expenses;
        }


        #endregion



    }
}
