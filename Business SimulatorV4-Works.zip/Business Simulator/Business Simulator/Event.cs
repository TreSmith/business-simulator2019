﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Simulator
{
    class Event : Player
    {

        #region Fields

        private int _seed;

        #endregion

        #region Constructor

        public Event(string name) : base(name)
        {
            base.Name = name;
        }

        #endregion

        #region Methods

        public string GetRandomEvent(Stock s)
        {
            string desc = "";
            Random rnd = new Random();
            

            _seed = rnd.Next(1, 25);
            desc = RandomEvent(_seed, s);    //Get random event and return as desc
            
            return desc;
        }

        private string RandomEvent(int x, Stock s)
        {
            string desc="";
            //Switch Statement to Declare Event
            switch(x)
            {
                case 1:
                    desc = "Guy dropped $500 in your store and didn't claim it after 30 days, I guess it's yours? :)\n";
                    base.Money += 500;
                    break;
                case 2:
                    desc = "You were robbed last night! You lose $500! :(\n";
                    base.Money -= 500;
                    break;
                case 3:
                    if (s.tv > 5)
                    {
                        s.tv-=5;
                        desc = "Aliens Abducted your stock! They stole 5 TVs to throw a superbowl party.\n";
                        s.currentstock -= (5 * s.TVStore);
                    }
                    if (s.tv < 5 && s.tv > 0)
                    {
                        s.tv--;
                        desc = "Aliens adbducted your stock! They stole 1 TV to throw a superbowl party.\n";
                        s.currentstock -= (s.TVStore);
                    }
                    else
                        desc = "Aliens came to abduct your stock to throw a superbowl party but you didn't have any TVs, they left an angry letter.\n";
                    break;
                case 4:
                    desc = "Florida man rides alligator into your store...you have to pay $2000 in damages\n";
                    base.Money -= 2000;
                    break;
                case 5:
                    if (base.RoundNum > 20)
                    {
                        desc = "An asteroid hits the earth and completely obbliterates the world...somehow your store is left on a chunk of the earth but you have no living customers...You LOSE\n";
                        base.Lose = true;
                    }
                    else
                    {
                        desc = "An asteroid was headed towards earth but NASA figured out a way to redirect it. Everyone was so scared during the chaos they dropped their wallets. You gained $2000\n";
                    }
                    break;
                case 6:
                    desc = "Your dad comes in the store and embarrases you in front of a regular customer. You give him $15 for his troubles\n";
                    base.Money -=15;
                    break;
                case 7:
                    desc = "Yeehaw you won the lottery! That's a million dollars in your pocket!!! Oh wait nevermind the government wants taxes. You get $1600\n";
                    base.Money += 1600;
                    break;
                case 8:
                    desc = "Wowza! You spotted a celebrity in your store. That's cool I guess put a picture on the wall or something idk...\n";
                    break;
                case 9:
                    desc = "A washing machines falls through the ceiling costs ya $5000 to fix...sorry bro\n";
                    base.Money -= 5000;
                    break;
                case 10:
                    if (s.phone + s.currentstock <= s.MaxStock)
                    {
                        desc = "A strange man left his cell phone on the floor and you take it and put it on the shelf. Gain 1 phone stock.\n";
                        s.phone++;
                        s.currentstock += s.PhoneStore; //Increment stock space to take up space
                    }
                    else
                    {
                        desc = "A strange man left his cell phone on the floor but you had no shelf space to store it...you threw it in the trash can like a good samaratin would.\n";
                    }
                    break;
                case 11:
                    if (s.tv > 0)
                    {
                        desc = "Some group of dumb kids were messing around and they broke your Stock...you Lose 1 TV\n";
                        s.tv--;
                        s.currentstock -= s.TVStore;
                    }
                    else
                    {
                        desc = "You followed in Walmart's footsteps by firing all the greeters who needed jobs. Gain $2000\n";
                    }
                    break;
                case 12:
                    desc = "You had a nightmare last night, doesn't really effect the store but it was pretty scary.\n";
                    break;
                case 13:
                    desc = "Some kids come into your store wearing some sick shoes, they con you into buying them. They don't fit you but they look pretty rad. You lose $200\n";
                    base.Money -= 200;
                    break;
                case 14:
                    break;
                case 15:

                    desc = "It rained today and you had the windows open. Some of your computer stock was destroyed :(\n";
                    s.computer = s.computer - (s.computer % 3);
                    break;
                default:
                    desc = "Nothing interesting happened today\n";
                    break;
            }

            return desc;

        }

        #endregion


    }
}
