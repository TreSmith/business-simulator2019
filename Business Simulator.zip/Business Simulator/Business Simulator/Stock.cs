﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Simulator
{
    class Stock
    {
        #region Fields

        private const int _defaulcellcost = 100;
        private const int _defaulttvcost = 150;
        private const int _defaultPCcost = 250;

        private const int _defaultphone = 0;
        private const int _defaulttv = 0;
        private const int _defaultPC = 0;

        private const int _defaultmax=100;
        private const int _phoneStore=5;
        private const int _tvStore=15;
        private const int _computerStore = 10;

        public int phonecost;
        public int tvcost;
        public int computercost;

        public int phone;   //Amount of stock owned
        public int tv;
        public int computer;

        public int maxstock;
        public int currentstock=0;

        #endregion

        #region Constructor

        public Stock()     //Constructor
        {
            phonecost       = _defaulcellcost;
            tvcost          = _defaulttvcost;
            computercost    = _defaultPCcost;

            phone = _defaultphone;
            tv = _defaulttv;
            computer = _defaultPC;

            maxstock = _defaultmax;
        }

        #endregion

        #region Methods

        public void BuyStock(int amount, int type)
        {
            int stock=0;
            for (int i=0; i < amount; i++)
            {
               if(type == 0) //Cell Phone
                {
                    stock = stock + _phoneStore; //Check if storage is full
                    if (stock > maxstock)
                        break;
                    else
                    {
                        //Take money from Player's Balance
                        currentstock = currentstock + stock;
                        phone++;
                    }
                }

               if(type==1) //TV
                {
                    stock = stock + _tvStore; //Check if storage is full
                    if (stock > maxstock)
                        break;
                    else
                    {
                        //Take money from Player's Balance
                        currentstock = currentstock + stock;
                        tv++;
                    }
                }
               if(type == 2) //Computer
                {
                    stock = stock + _computerStore; //Check if storage is full
                    if (stock > maxstock)
                        break;
                    else
                    {
                        //Take money from Player's balance
                        currentstock = currentstock + stock; //If storage is not full then buy stock
                        computer++;
                    }
                }
            }


        }

        #endregion

    }
}
