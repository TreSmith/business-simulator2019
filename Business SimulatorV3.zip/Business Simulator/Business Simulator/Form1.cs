﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Business_Simulator
{
    public partial class Form1 : Form
    {
        Store stock;
        Event p1;
        int amount;
        string name;

        public Form1()
        {
            #region Class Intialization

            p1 = new Event("Tre");
            stock = new Store();

            #endregion

            InitializeComponent();

            #region TextBox Intialization
            name = TextPrompt.ShowDialog("Ready?", "What's your name?");

            FirstTime();

            IntializationofText();

            #endregion


        }

        #region Methods

        #region Purchase Methods

        private void phonebuy1_Click(object sender, EventArgs e)
        {
            amount = stock.BuyStock(1, 0, p1);   //Passes Flag 0 to represent Phone
            IntializationofText();

            if(amount == 0)
            {
                displayBox.Text += "\nNo phones purchased, are you out of money or storage space?\n";
            }
            else
                displayBox.Text += (amount + " phone(s) successfully purchased\n");
        }

        private void phonebuy10_Click(object sender, EventArgs e)
        {
            amount = stock.BuyStock(10, 0, p1);  //Passes Flag 0 to represent Phone
            IntializationofText();

            if (amount == 0)
            {
                displayBox.Text += "No phones purchased, are you out of money or storage space?\n";
            }
            else
                displayBox.Text += (amount + " phone(s) successfully purchased\n");

        }

        private void tvbuy1_Click(object sender, EventArgs e)
        {
            amount = stock.BuyStock(1, 1, p1);   //Passes Flag 1 to represent TV
            IntializationofText();
            displayBox.Text += (amount + " TV(s) successfully purchased\n");

            if (amount == 0)
            {
                displayBox.Text += "No TVs purchased, are you out of money or storage space?\n";
            }
            else
                displayBox.Text += (amount + " TV(s) successfully purchased\n");
        }

        private void tvbuy10_Click(object sender, EventArgs e)
        {
            amount = stock.BuyStock(10, 1, p1);  //Passes Flag 1 to represent TV
            IntializationofText();
            if (amount == 0)
            {
                displayBox.Text += "No TVs purchased, are you out of money or storage space?\n";
            }
            else
                displayBox.Text += (amount + " TV(s) successfully purchased\n");
        }

        private void pcbuy1_Click(object sender, EventArgs e)
        {
            amount = stock.BuyStock(1, 2, p1);   //Passes Flag 2 to represent PC
            IntializationofText();
            if (amount == 0)
            {
                displayBox.Text += "No TVs purchased, are you out of money or storage space?\n";
            }
            else
                displayBox.Text += (amount + " computer(s) successfully purchased\n");
        }

        private void pcbuy10_Click(object sender, EventArgs e)
        {
            amount = stock.BuyStock(10, 2, p1);  //Passes Flag 2 to represent PC
            IntializationofText();
            if (amount == 0)
            {
                displayBox.Text += "No TVs purchased, are you out of money or storage space?\n";
            }
            else
                displayBox.Text += (amount + " computer(s) successfully purchased\n");

        }

        #endregion

        private void quitbtn_Click(object sender, EventArgs e)
        { 
            //Logic to quit game
            DialogResult dialog = new DialogResult();

            dialog = MessageBox.Show("Are you sure you want to quit?", "Alert!", MessageBoxButtons.YesNo);

            if (dialog == DialogResult.Yes)
            {
                Application.Exit();
            }

        }

        private void Nextround_Click(object sender, EventArgs e)
        {
            Nextroundcommands();

            //Activate Events, Pass Information to Display
        }

        private void SmallStore_Click(object sender, EventArgs e)
        {
            if (smStoreBox.Text != "Purchased")
            {
                if (medStoreBox.Text != "Purchased" && lgStoreBox.Text != "Purchased")
                {
                    if (p1._money >= 25000)
                    {
                        smStoreBox.Text = "Purchased";
                        p1._money -= 25000;
                        stock.SmallStoreUpgrade();
                        //Logic To implement faster store
                    }
                }
            }
            else
            {
                displayBox.Text += "Already Purchased Small Store!\n";
            }
            IntializationofText();
        }

        private void mediumStore_Click(object sender, EventArgs e)
        {
            if (medStoreBox.Text != "Purchased")
            {
                if (lgStoreBox.Text != "Purchased")
                {
                    if (p1._money >= 100000)
                    {
                        medStoreBox.Text = "Purchased";
                        p1._money -= 100000;
                        stock.MediumStoreUpgrade();
                        //Logic To implement faster store
                    }
                }
            }
            else
            {
                displayBox.Text += "Already Purchased Small Store!\n";
            }
            IntializationofText();
        }


        private void largeStore_Click(object sender, EventArgs e)
        {
            if (lgStoreBox.Text != "Purchased")
            {
                if (p1._money >= 200000)
                {
                    medStoreBox.Text = "Purchased";
                    p1._money -= 200000;
                    stock.MediumStoreUpgrade();
                    //Logic To implement faster store
                }

            }
            else
            {
                displayBox.Text += "Already Purchased Small Store!\n";
            }
            IntializationofText();
        }

        private void IntializationofText(string desc)   //Used to put words into displaybox
        {
            displayBox.Text += desc;        //Function Overloading
            IntializationofText();
        }

        private void FirstTime()    //Used to intilize everything that only happens at the begining
        {
            labelPhone1.Text = ("$" + stock.phonecost);
            labelPhone10.Text = ("$" + (stock.phonecost * 10));
            labelTV1.Text = ("$" + stock.tvcost);
            labelTV10.Text = ("$" + (stock.tvcost * 10));
            labelPC1.Text = ("$" + stock.computercost);
            labelPC10.Text = ("$" + (stock.computercost * 10));
            smStoreBox.Text = "$25000";
            medStoreBox.Text = "$100000";
            lgStoreBox.Text = "$200000";
            nameBox.Text = (name +"'s Electronics Store!"); //Intial Textbox name
            placeholder.Text = "Buying a bigger store\nincreases storage\n space but also\n increases expenses\n";
        }

        private void IntializationofText()              //used if you don't need to put words in displaybox
        {
            moneyBox.Text = ("Total Money: " + p1._money );
            roundNum.Text = ("Round Number: " + p1.RoundNum + "\n");
            stockSpace.Text = ("Space Taken up by Stock:\nPhones: 5 | TVs: 15 | Computers: 10\nCurrently Owned\nPhones: " + stock.phone + " | TVs: " + stock.tv + " | Computers: " + stock.computer);
            stockDisplay.Text = ("Total Stock Used: " + stock.currentstock + "/" + stock.MaxStock);
            displayBox.SelectionStart = displayBox.Text.Length;
            displayBox.ScrollToCaret();

            if (p1._money <= 0 || p1.Lose == true)  //If you run out of money you lose
            {
                displayBox.Text += "YOU LOSE";
                DialogResult gameover = new DialogResult();
                gameover = MessageBox.Show("Game over! You made it " + p1.RoundNum + " rounds", "Game Over!", MessageBoxButtons.OK);
                Application.Exit();
            }


        }

        private void Nextroundcommands()
        {
            string desc="";
            int expenses, x;
            for (int i = 0; i < 3; i++)
            {

                x = stock.SellStock(i, p1);
                switch (i)
                {
                    case 0:
                        desc += (x + " total $ made from phones\n");
                        break;
                    case 1:
                        desc += (x + " total $ made from TVs\n");
                        break;
                    case 2:
                        desc += (x + " total $ made from Computers\n\n");
                        break;
                }
            }
                expenses = stock.Expenses(p1);

            p1.RoundNum++;
            displayBox.Text += ("\n========\nROUND " + p1.RoundNum + "\n========\n$" + expenses + " total expenses paid.\n\n");
            desc += p1.getRandomEvent(stock);
            IntializationofText(desc);
        }

        #endregion

    }
}
