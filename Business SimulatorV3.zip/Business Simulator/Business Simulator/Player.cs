﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Simulator
{
    class Player
    {
        #region Fields

        static private int _defaultMoney = 25000;
        private bool _lose = false;


        public int _money;
        public int RoundNum;
        public string Name;

        #endregion

        #region Getters and Setters

        public int DefaultMoney
        {
            get
            {
                return _defaultMoney;
            }
        }

        public bool Lose        //Boolean Value to check if you lost the game
        {
            get
            {
                return _lose;
            }
            set
            {
                _lose = value;
            }

        }

        #endregion


        #region Constructor

        public Player(string name)
        {
            _money = _defaultMoney;
            Name = name;
        }

        #endregion



    }
}
