﻿namespace Business_Simulator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.nextround = new System.Windows.Forms.Button();
            this.phonebuy10 = new System.Windows.Forms.Button();
            this.tvbuy1 = new System.Windows.Forms.Button();
            this.phonebuy1 = new System.Windows.Forms.Button();
            this.tvbuy10 = new System.Windows.Forms.Button();
            this.pcbuy1 = new System.Windows.Forms.Button();
            this.pcbuy10 = new System.Windows.Forms.Button();
            this.quitbtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelPhone1 = new System.Windows.Forms.Label();
            this.labelPhone10 = new System.Windows.Forms.Label();
            this.labelTV1 = new System.Windows.Forms.Label();
            this.labelTV10 = new System.Windows.Forms.Label();
            this.labelPC1 = new System.Windows.Forms.Label();
            this.labelPC10 = new System.Windows.Forms.Label();
            this.roundNum = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.smallStore = new System.Windows.Forms.Button();
            this.mediumStore = new System.Windows.Forms.Button();
            this.largeStore = new System.Windows.Forms.Button();
            this.moneyBox = new System.Windows.Forms.TextBox();
            this.smStoreBox = new System.Windows.Forms.TextBox();
            this.medStoreBox = new System.Windows.Forms.TextBox();
            this.lgStoreBox = new System.Windows.Forms.TextBox();
            this.displayBox = new System.Windows.Forms.RichTextBox();
            this.stockDisplay = new System.Windows.Forms.TextBox();
            this.stockSpace = new System.Windows.Forms.Label();
            this.nameBox = new System.Windows.Forms.Label();
            this.placeholder = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // nextround
            // 
            this.nextround.Location = new System.Drawing.Point(670, 476);
            this.nextround.Name = "nextround";
            this.nextround.Size = new System.Drawing.Size(116, 87);
            this.nextround.TabIndex = 0;
            this.nextround.Text = "Next Round";
            this.nextround.UseVisualStyleBackColor = true;
            this.nextround.Click += new System.EventHandler(this.Nextround_Click);
            // 
            // phonebuy10
            // 
            this.phonebuy10.Location = new System.Drawing.Point(177, 195);
            this.phonebuy10.Name = "phonebuy10";
            this.phonebuy10.Size = new System.Drawing.Size(92, 75);
            this.phonebuy10.TabIndex = 2;
            this.phonebuy10.Text = "Buy 10";
            this.phonebuy10.UseVisualStyleBackColor = true;
            this.phonebuy10.Click += new System.EventHandler(this.phonebuy10_Click);
            // 
            // tvbuy1
            // 
            this.tvbuy1.Location = new System.Drawing.Point(65, 290);
            this.tvbuy1.Name = "tvbuy1";
            this.tvbuy1.Size = new System.Drawing.Size(92, 75);
            this.tvbuy1.TabIndex = 3;
            this.tvbuy1.Text = "Buy 1";
            this.tvbuy1.UseVisualStyleBackColor = true;
            this.tvbuy1.Click += new System.EventHandler(this.tvbuy1_Click);
            // 
            // phonebuy1
            // 
            this.phonebuy1.Location = new System.Drawing.Point(65, 195);
            this.phonebuy1.Name = "phonebuy1";
            this.phonebuy1.Size = new System.Drawing.Size(92, 75);
            this.phonebuy1.TabIndex = 4;
            this.phonebuy1.Text = "Buy 1";
            this.phonebuy1.UseVisualStyleBackColor = true;
            this.phonebuy1.Click += new System.EventHandler(this.phonebuy1_Click);
            // 
            // tvbuy10
            // 
            this.tvbuy10.Location = new System.Drawing.Point(177, 290);
            this.tvbuy10.Name = "tvbuy10";
            this.tvbuy10.Size = new System.Drawing.Size(92, 75);
            this.tvbuy10.TabIndex = 5;
            this.tvbuy10.Text = "Buy 10";
            this.tvbuy10.UseVisualStyleBackColor = true;
            this.tvbuy10.Click += new System.EventHandler(this.tvbuy10_Click);
            // 
            // pcbuy1
            // 
            this.pcbuy1.Location = new System.Drawing.Point(65, 383);
            this.pcbuy1.Name = "pcbuy1";
            this.pcbuy1.Size = new System.Drawing.Size(92, 75);
            this.pcbuy1.TabIndex = 6;
            this.pcbuy1.Text = "Buy 1";
            this.pcbuy1.UseVisualStyleBackColor = true;
            this.pcbuy1.Click += new System.EventHandler(this.pcbuy1_Click);
            // 
            // pcbuy10
            // 
            this.pcbuy10.Location = new System.Drawing.Point(177, 383);
            this.pcbuy10.Name = "pcbuy10";
            this.pcbuy10.Size = new System.Drawing.Size(92, 75);
            this.pcbuy10.TabIndex = 7;
            this.pcbuy10.Text = "Buy 10";
            this.pcbuy10.UseVisualStyleBackColor = true;
            this.pcbuy10.Click += new System.EventHandler(this.pcbuy10_Click);
            // 
            // quitbtn
            // 
            this.quitbtn.Location = new System.Drawing.Point(528, 476);
            this.quitbtn.Name = "quitbtn";
            this.quitbtn.Size = new System.Drawing.Size(116, 87);
            this.quitbtn.TabIndex = 8;
            this.quitbtn.Text = "Quit";
            this.quitbtn.UseVisualStyleBackColor = true;
            this.quitbtn.Click += new System.EventHandler(this.quitbtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(12, 226);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 9;
            this.label1.Text = "Phones";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Location = new System.Drawing.Point(12, 321);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "TVs";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Location = new System.Drawing.Point(2, 414);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(57, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Computers";
            // 
            // labelPhone1
            // 
            this.labelPhone1.AutoSize = true;
            this.labelPhone1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.labelPhone1.Location = new System.Drawing.Point(94, 245);
            this.labelPhone1.Name = "labelPhone1";
            this.labelPhone1.Size = new System.Drawing.Size(35, 13);
            this.labelPhone1.TabIndex = 12;
            this.labelPhone1.Text = "label4";
            // 
            // labelPhone10
            // 
            this.labelPhone10.AutoSize = true;
            this.labelPhone10.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.labelPhone10.Location = new System.Drawing.Point(205, 245);
            this.labelPhone10.Name = "labelPhone10";
            this.labelPhone10.Size = new System.Drawing.Size(35, 13);
            this.labelPhone10.TabIndex = 13;
            this.labelPhone10.Text = "label5";
            // 
            // labelTV1
            // 
            this.labelTV1.AutoSize = true;
            this.labelTV1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.labelTV1.Location = new System.Drawing.Point(97, 339);
            this.labelTV1.Name = "labelTV1";
            this.labelTV1.Size = new System.Drawing.Size(35, 13);
            this.labelTV1.TabIndex = 14;
            this.labelTV1.Text = "label4";
            // 
            // labelTV10
            // 
            this.labelTV10.AutoSize = true;
            this.labelTV10.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.labelTV10.Location = new System.Drawing.Point(205, 339);
            this.labelTV10.Name = "labelTV10";
            this.labelTV10.Size = new System.Drawing.Size(35, 13);
            this.labelTV10.TabIndex = 15;
            this.labelTV10.Text = "label5";
            // 
            // labelPC1
            // 
            this.labelPC1.AutoSize = true;
            this.labelPC1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.labelPC1.Location = new System.Drawing.Point(97, 436);
            this.labelPC1.Name = "labelPC1";
            this.labelPC1.Size = new System.Drawing.Size(35, 13);
            this.labelPC1.TabIndex = 16;
            this.labelPC1.Text = "label6";
            // 
            // labelPC10
            // 
            this.labelPC10.AutoSize = true;
            this.labelPC10.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.labelPC10.Location = new System.Drawing.Point(208, 435);
            this.labelPC10.Name = "labelPC10";
            this.labelPC10.Size = new System.Drawing.Size(10, 13);
            this.labelPC10.TabIndex = 17;
            this.labelPC10.Text = " ";
            // 
            // roundNum
            // 
            this.roundNum.Location = new System.Drawing.Point(65, 72);
            this.roundNum.Name = "roundNum";
            this.roundNum.ReadOnly = true;
            this.roundNum.Size = new System.Drawing.Size(204, 20);
            this.roundNum.TabIndex = 18;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pictureBox1.Location = new System.Drawing.Point(302, 195);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(342, 263);
            this.pictureBox1.TabIndex = 19;
            this.pictureBox1.TabStop = false;
            // 
            // smallStore
            // 
            this.smallStore.Location = new System.Drawing.Point(321, 211);
            this.smallStore.Name = "smallStore";
            this.smallStore.Size = new System.Drawing.Size(77, 59);
            this.smallStore.TabIndex = 20;
            this.smallStore.Text = "Small Store";
            this.smallStore.UseVisualStyleBackColor = true;
            this.smallStore.Click += new System.EventHandler(this.SmallStore_Click);
            // 
            // mediumStore
            // 
            this.mediumStore.Location = new System.Drawing.Point(321, 298);
            this.mediumStore.Name = "mediumStore";
            this.mediumStore.Size = new System.Drawing.Size(77, 59);
            this.mediumStore.TabIndex = 21;
            this.mediumStore.Text = "Medium Store";
            this.mediumStore.UseVisualStyleBackColor = true;
            this.mediumStore.Click += new System.EventHandler(this.mediumStore_Click);
            // 
            // largeStore
            // 
            this.largeStore.Location = new System.Drawing.Point(321, 383);
            this.largeStore.Name = "largeStore";
            this.largeStore.Size = new System.Drawing.Size(77, 59);
            this.largeStore.TabIndex = 22;
            this.largeStore.Text = "Large Store";
            this.largeStore.UseVisualStyleBackColor = true;
            this.largeStore.Click += new System.EventHandler(this.largeStore_Click);
            // 
            // moneyBox
            // 
            this.moneyBox.Location = new System.Drawing.Point(302, 169);
            this.moneyBox.Name = "moneyBox";
            this.moneyBox.ReadOnly = true;
            this.moneyBox.Size = new System.Drawing.Size(204, 20);
            this.moneyBox.TabIndex = 23;
            // 
            // smStoreBox
            // 
            this.smStoreBox.Location = new System.Drawing.Point(420, 231);
            this.smStoreBox.Name = "smStoreBox";
            this.smStoreBox.ReadOnly = true;
            this.smStoreBox.Size = new System.Drawing.Size(100, 20);
            this.smStoreBox.TabIndex = 24;
            // 
            // medStoreBox
            // 
            this.medStoreBox.Location = new System.Drawing.Point(420, 318);
            this.medStoreBox.Name = "medStoreBox";
            this.medStoreBox.ReadOnly = true;
            this.medStoreBox.Size = new System.Drawing.Size(100, 20);
            this.medStoreBox.TabIndex = 25;
            // 
            // lgStoreBox
            // 
            this.lgStoreBox.Location = new System.Drawing.Point(420, 403);
            this.lgStoreBox.Name = "lgStoreBox";
            this.lgStoreBox.ReadOnly = true;
            this.lgStoreBox.Size = new System.Drawing.Size(100, 20);
            this.lgStoreBox.TabIndex = 26;
            // 
            // displayBox
            // 
            this.displayBox.Location = new System.Drawing.Point(650, 25);
            this.displayBox.Name = "displayBox";
            this.displayBox.ReadOnly = true;
            this.displayBox.Size = new System.Drawing.Size(196, 433);
            this.displayBox.TabIndex = 27;
            this.displayBox.Text = "";
            // 
            // stockDisplay
            // 
            this.stockDisplay.Location = new System.Drawing.Point(65, 169);
            this.stockDisplay.Name = "stockDisplay";
            this.stockDisplay.ReadOnly = true;
            this.stockDisplay.Size = new System.Drawing.Size(204, 20);
            this.stockDisplay.TabIndex = 28;
            // 
            // stockSpace
            // 
            this.stockSpace.AutoSize = true;
            this.stockSpace.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.stockSpace.Location = new System.Drawing.Point(62, 106);
            this.stockSpace.Name = "stockSpace";
            this.stockSpace.Size = new System.Drawing.Size(40, 13);
            this.stockSpace.TabIndex = 29;
            this.stockSpace.Text = "wowza";
            // 
            // nameBox
            // 
            this.nameBox.AutoSize = true;
            this.nameBox.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.nameBox.Location = new System.Drawing.Point(302, 78);
            this.nameBox.Name = "nameBox";
            this.nameBox.Size = new System.Drawing.Size(35, 13);
            this.nameBox.TabIndex = 30;
            this.nameBox.Text = "label4";
            // 
            // placeholder
            // 
            this.placeholder.AutoSize = true;
            this.placeholder.Location = new System.Drawing.Point(526, 231);
            this.placeholder.Name = "placeholder";
            this.placeholder.Size = new System.Drawing.Size(62, 13);
            this.placeholder.TabIndex = 31;
            this.placeholder.Text = "placeholder";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(858, 594);
            this.Controls.Add(this.placeholder);
            this.Controls.Add(this.nameBox);
            this.Controls.Add(this.stockSpace);
            this.Controls.Add(this.stockDisplay);
            this.Controls.Add(this.displayBox);
            this.Controls.Add(this.lgStoreBox);
            this.Controls.Add(this.medStoreBox);
            this.Controls.Add(this.smStoreBox);
            this.Controls.Add(this.moneyBox);
            this.Controls.Add(this.largeStore);
            this.Controls.Add(this.mediumStore);
            this.Controls.Add(this.smallStore);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.roundNum);
            this.Controls.Add(this.labelPC10);
            this.Controls.Add(this.labelPC1);
            this.Controls.Add(this.labelTV10);
            this.Controls.Add(this.labelTV1);
            this.Controls.Add(this.labelPhone10);
            this.Controls.Add(this.labelPhone1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.quitbtn);
            this.Controls.Add(this.pcbuy10);
            this.Controls.Add(this.pcbuy1);
            this.Controls.Add(this.tvbuy10);
            this.Controls.Add(this.phonebuy1);
            this.Controls.Add(this.tvbuy1);
            this.Controls.Add(this.phonebuy10);
            this.Controls.Add(this.nextround);
            this.Name = "Form1";
            this.Text = "Business Simulator";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button nextround;
        private System.Windows.Forms.Button phonebuy10;
        private System.Windows.Forms.Button tvbuy1;
        private System.Windows.Forms.Button phonebuy1;
        private System.Windows.Forms.Button tvbuy10;
        private System.Windows.Forms.Button pcbuy1;
        private System.Windows.Forms.Button pcbuy10;
        private System.Windows.Forms.Button quitbtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label labelPhone1;
        private System.Windows.Forms.Label labelPhone10;
        private System.Windows.Forms.Label labelTV1;
        private System.Windows.Forms.Label labelTV10;
        private System.Windows.Forms.Label labelPC1;
        private System.Windows.Forms.Label labelPC10;
        private System.Windows.Forms.TextBox roundNum;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button smallStore;
        private System.Windows.Forms.Button mediumStore;
        private System.Windows.Forms.Button largeStore;
        private System.Windows.Forms.TextBox moneyBox;
        private System.Windows.Forms.TextBox smStoreBox;
        private System.Windows.Forms.TextBox medStoreBox;
        private System.Windows.Forms.TextBox lgStoreBox;
        private System.Windows.Forms.RichTextBox displayBox;
        private System.Windows.Forms.TextBox stockDisplay;
        private System.Windows.Forms.Label stockSpace;
        private System.Windows.Forms.Label nameBox;
        private System.Windows.Forms.Label placeholder;
    }
}

