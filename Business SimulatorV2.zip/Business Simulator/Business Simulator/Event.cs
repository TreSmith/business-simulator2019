﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Simulator
{
    class Event : Player
    {




        public Event(string name) : base(name)
        {
            base.Name = name;
        }

        public string getRandomEvent(Stock s)
        {
            string desc = "";
            Random rnd = new Random();
            int seed;

            int events;
            events = (base.RoundNum / 10) + 1; //Every 10th Round implement a second Event to activate

            for(int k=0; k < events; k++)
            {
                seed = rnd.Next(1, 25);
                desc = desc + "\n" + randomEvent(seed, s);
            }

            return desc;
        }

        private string randomEvent(int x, Stock s)
        {
            string desc="Default";
            //Switch Statement to Declare Event
            int value;


            switch(x)
            {
                case 1:
                    desc = "Guy dropped $500 in your store and didn't claim it after 30 days, I guess it's yours? :)";
                    base._money += 500;
                    break;
                case 2:
                    desc = "You were robbed last night! You lose $500! :(";
                    base._money -= 500;
                    break;
                case 3:
                    if (s.tv > 5)
                    {
                        s.tv-=5;
                        desc = "Aliens Abducted your stock! They stole 5 TVs to throw a superbowl party.";
                    }
                    if (s.tv < 5 && s.tv > 0)
                    {
                        s.tv--;
                        desc = "Aliens adbducted your stock! They stole 1 TV to throw a superbowl party.";
                    }
                    else
                        desc = "Aliens came to abduct your stock to throw a superbowl party but you didn't have any TVs, they left an angry letter.";
                    break;
                case 4:
                    desc = "Florida man rides alligator into your store...you have to pay $2000 in damages";
                    base._money -= 2000;
                    break;
                case 5:
                    desc = "An asteroid hits the earth and completely obbliterates the world...somehow your store is left on a chunk of the earth but you have no living customers...You LOSE";
                    base._money = 0;
                    break;
                case 6:
                    desc = "Your dad comes in the store and embarrases you in front of a regular customer. You give him $15 for his troubles";
                    base._money -=15;
                    break;
                case 7:
                    desc = "Yeehaw you won the lottery! That's a million dollars in your pocket!!! Oh wait nevermind the government wants taxes. You get $1600";
                    base._money += 1600;
                    break;
                case 8:
                    desc = "Wowza! You spotted a celebrity in your store. That's cool I guess put a picture on the wall or something idk...";
                    break;
                case 9:
                    desc = "A washing machines falls through ";
                    break;
                case 10:
                    break;
                case 11:
                    break;
                case 12:
                    break;
                case 13:
                    break;
                case 14:
                    break;
                case 15:
                    break;
                default:
                    desc = "Normal Day for once I suppose :/";
                    break;
            }














            return desc;



        }




    }
}
