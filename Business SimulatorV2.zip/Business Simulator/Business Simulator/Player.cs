﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Business_Simulator
{
    class Player
    {
        static private int _defaultMoney = 1000;

        public int _money;
        public int RoundNum;
        public string Name;

        public Player(string name)
        {
            _money = _defaultMoney;
            Name = name;
        }

         
    }
}
