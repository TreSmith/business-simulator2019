﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Business_Simulator
{
    public partial class Form1 : Form
    {
        //var p1 = new Player("Tre");
        Stock stock;
        Event p1;

        public Form1()
        {
            #region Class Intialization

            p1 = new Event("Tre");
            stock = new Stock();

            #endregion

            InitializeComponent();

            #region TextBox Intialization
            smStoreBox.Text = "$25000";
            medStoreBox.Text = "$100000";
            lgStoreBox.Text = "$200000";

            intializationofText();

            #endregion
        }

        private void phonebuy1_Click(object sender, EventArgs e)
        {
            stock.BuyStock(1, 0, p1);   //Passes Flag 0 to represent Phone
        }

        private void phonebuy10_Click(object sender, EventArgs e)
        {
            stock.BuyStock(10, 0, p1);  //Passes Flag 0 to represent Phone
        }

        private void tvbuy1_Click(object sender, EventArgs e)
        {
            stock.BuyStock(1, 1, p1);   //Passes Flag 1 to represent TV
        }

        private void tvbuy10_Click(object sender, EventArgs e)
        {
            stock.BuyStock(10, 1, p1);  //Passes Flag 1 to represent TV
        }

        private void pcbuy1_Click(object sender, EventArgs e)
        {
            stock.BuyStock(1, 2, p1);   //Passes Flag 2 to represent PC
        }

        private void pcbuy10_Click(object sender, EventArgs e)
        {
            stock.BuyStock(10, 2, p1);  //Passes Flag 2 to represent PC
        }

        private void quitbtn_Click(object sender, EventArgs e)
        {
            //Application.Exit();
            //Logic to quit game
            DialogResult dialog = new DialogResult();

            dialog = MessageBox.Show("Getting Sick of it? I see how it is...", "Alert!", MessageBoxButtons.YesNo);

            if (dialog == DialogResult.Yes)
            {
                Application.Exit();
            }


        }

        private void nextround_Click(object sender, EventArgs e)
        {
            p1.RoundNum++;
            priceCheck();
            intializationofText();
            //Activate Events, Pass Information to Display
        }

        private void priceCheck()
        {
            
        }


        private void intializationofText()
        {
            moneyBox.Text = ("Total Money: " + p1._money );
            roundNum.Text = ("Round Number: " + p1.RoundNum + "\n");

            //Buy Button Money
            labelPhone1.Text = ("$" + stock.phonecost);
            labelPhone10.Text = ("$" + (stock.phonecost * 10));
            labelTV1.Text = ("$" + stock.tvcost);
            labelTV10.Text = ("$" + (stock.tvcost * 10));
            labelPC1.Text = ("$" + stock.computercost);
            labelPC10.Text = ("$" + (stock.computercost * 10));


        }

        private void smallStore_Click(object sender, EventArgs e)
        {
            if(smStoreBox.Text != "Purchased")
            {
                if()
                {

                }
            }
            else
            {
                //Put error in display saying you already purchased it
            }
        }
    }
}
